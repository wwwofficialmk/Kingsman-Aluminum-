# Premium Zinc & Roofing Materials Website

Professional website for a zinc and roofing materials business located at **Integrated Building Materials Market, Abakaliki, Ebonyi State**.

**WhatsApp:** 07017751785  
**Hours:** Monday – Saturday, 8:00 AM – 5:00 PM

---

## How to Put This Website on GitHub (GitHub Pages)

### Option 1 – Fastest Method (Recommended)

1. Go to [GitHub.com](https://github.com) and log in (or create a free account).
2. Click the **+** button (top right) → **New repository**.
3. Name it something like `zinc-website` or `abakaliki-zinc`.
4. Make it **Public**.
5. Click **Create repository**.
6. On the new page, click **uploading an existing file**.
7. Drag and drop the `index.html` file (and this README if you want).
8. Click **Commit changes**.
9. Go to **Settings** → **Pages** (left sidebar).
10. Under **Source**, select **Deploy from a branch**.
11. Choose branch: `main` (or `master`) and folder: `/ (root)`.
12. Click **Save**.
13. Wait 1–2 minutes. Your website will be live at:  
   `https://yourusername.github.io/zinc-website`

### Option 2 – Using Git (if you know Git)

```bash
git clone https://github.com/yourusername/zinc-website.git
cd zinc-website
# copy index.html into the folder
git add .
git commit -m "Add zinc website"
git push
```

Then enable GitHub Pages as described above.

---

## Customization Tips

- **Change business name**: Search for “Zinc & Roofing” in the HTML and replace it.
- **Add your own photos**: Replace the Unsplash image URLs with your own product photos (upload them to the same GitHub repo and link them).
- **Update phone number**: Search for `07017751785` or `2347017751785` and replace.
- **Add more products**: Copy any product card and edit the text + image.

---

## Features Included

- Beautiful modern design
- Mobile responsive
- Sticky WhatsApp button
- Product showcase (Metro Tiles, Urban Planet, Tiger Sumo, EP Zinc, Sumo Zinc, POP Ceiling Boards)
- Location & opening hours
- Fast loading
- SEO-friendly meta tags

Enjoy your new website!
